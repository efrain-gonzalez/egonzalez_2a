/*Clase Logic
  Efrain Gonzalez
*/
import java.util.*;

/**
 * @author Efrain
 */
public class Logic {

    /**
     * Default constructor
     */
    public Logic() {
    }

    /**
     * 
     */
    private int n;

    /**
     * 
     */
    private String data;

    /**
     * 
     */
    private String[] arrData;

    /**
     * 
     */
    private int lCounter;

    /**
     * 
     */
    private int mCounter;

    /**
     * @return
     */
    public void logic2a() {
        // TODO implement here
        Input myInput = new Input();
        Output myOut = new Output();
        
	Data myData = new Data();
        LineCounter myLCounter = new LineCounter();
		//Media myMedia = new Media(); COMENTARIO
		//DesvEst myDesv = new DesvEst(); COMENTARIO

        data = myInput.readData("C:\\Users\\Efrain\\Documents\\NetBeansProjects"
                + "\\2a\\src\\Output.java");
        arrData = myData.saveData(data);
        n = arrData.length;
        System.out.println("Total de lineas de archivo:  " + n);
        
        
        lCounter = myLCounter.countLines(arrData, n);
        System.out.println("    Lineas de codigo :  " + lCounter);
        
        MethodCounter myMCounter= new MethodCounter();
        mCounter = myMCounter.countMethods(arrData, n);
        System.out.println("    numero de metodos :  " + mCounter);
        //media = myMedia.getMedia(arrData, n); COMENTARIOS
        //System.out.println("media :  " + media);

	//desv = myDesv.getDesvEstd(media, arrData, n); COMENTARIOS
        //System.out.println("desv std :  " + desv);
        
        myOut.writeData("C:\\Users\\Efrain\\Documents\\NetBeansProjects\\2a\\src\\result.txt", "Total de lineas de archivo = " + n + " Total lineas de codigo = " + lCounter + " Numero de metodos = " + mCounter);


    }

}