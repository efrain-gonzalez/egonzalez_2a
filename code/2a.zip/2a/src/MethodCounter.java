/*Clase App
  Efrain Gonzalez
*/
import java.util.*;

/**
 * @author Efrain
 */
public class MethodCounter {
    public int totalMethods;

    /**
     * 
     */
    public int totalLines=0;
    public String arrData;
    /**
     * Default constructor
     */
    
    public MethodCounter() {
    }

  
    public int countMethods(String[] dataList, int n) {
        // TODO implement here
        for(int x = 0; x<n; x++){

            arrData = dataList[x].trim();           

            
                while((arrData.startsWith("private") || arrData.startsWith("public") || 
                        arrData.startsWith("protected")) &&  arrData.contains("(") && 
                        arrData.contains(")") && arrData.contains("{")){

                    totalMethods++;
                    totalLines++;

                    for (x=x+1; x<n; x++){
                        arrData = dataList[x].trim();           
                        
                
                        if((arrData.startsWith("private") || arrData.startsWith("public") || 
                        arrData.startsWith("protected")) &&  arrData.contains("(") && 
                        arrData.contains(")") && arrData.contains("{")){

                            System.out.println("\n    Metodo Número " + totalMethods + "\n    Total de lineas: " + totalLines);
                            totalLines=1;
                            totalMethods++;

                        } else if (!("".equals(arrData) || arrData.startsWith("//") || 
                            arrData.startsWith("}") || arrData.startsWith("/*") 
                            || arrData.startsWith("*/") || 
                            arrData.startsWith("*"))) {
                                totalLines++;
                        }
                    }     
                }        
        }
        System.out.println("\n    Metodo Número " + totalMethods + "\n    Total de lineas: " + totalLines);
        return totalMethods;
    }

    }
