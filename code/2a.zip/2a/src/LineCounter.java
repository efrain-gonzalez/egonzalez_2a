/*
    Clase LineCounter
    Efrain Gonzalez
*/
public class LineCounter {

    public LineCounter() {
    }
    public String arrData;
    /**
     * @param dataList 
     * @param n
     */
    private int totalLines = 0;
    public int countLines(String[] dataList, int n) {
        for(int x = 0; x<n; x++){

            arrData = dataList[x].trim();
            if (!("".equals(arrData) || arrData.startsWith("//") || 
                arrData.startsWith("}") || arrData.startsWith("/*") 
                || arrData.startsWith("*/") || 
                arrData.startsWith("*"))) {
                totalLines++;
            }
        }
        return totalLines - 2;
    }
}